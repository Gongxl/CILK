package tasks;

import api.Closure;
import api.Task;

public class FibTask extends Task<Integer> {
	@Override
	public Integer call() throws Exception {
		// check 
		return null;
	}
	@Override
	public Closure<Integer> generateSuccesor() {
		return new Closure(result, null);
	}
	
}
