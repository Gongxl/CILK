package space;

public class SpaceImpl {

}
