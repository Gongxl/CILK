package system;

import java.rmi.Remote;
import java.rmi.RemoteException;

import api.Closure;
import api.Result;
import api.Task;

public interface Computer extends Remote {
	<T> Result executeTask(Task<T> t) throws RemoteException;
	void exit() throws RemoteException;
	<T> void issueNewTask(Task<T> subTask) throws RemoteException;
	<T> void generateSuccessor(Closure<T> successor) throws RemoteException;
}
