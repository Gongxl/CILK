package system;

import java.rmi.RemoteException;
import java.util.concurrent.BlockingQueue;

import api.Result;
import api.Space;
import api.Task;
import api.TemporaryResult;

public class ComputerProxy extends Thread {
	private Computer computer;
	private Space space;
	private boolean running;
	@Override
	public void run() {
		super.run();
		System.out.println("Start a new proxy!");
		while(true) {
			Result value = null;
			Task task = null;
			try {
				synchronized(this) {
					task = space.fetchTask();
					if(!this.running) return;
					value = computer.executeTask(task);
				}
				if(value.getTaskReturnValue().getType() == TemporaryResult.Type.VALUE)
					space.issueNewTask(task.generateSubTask());
				else
					space.generateSuccessor(task.generateSuccessor());
			} catch (RemoteException e) {
				e.printStackTrace();
				try {
					space.restoreTask(task);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}
