package api;

import java.io.Serializable;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;

public abstract class Task<V> implements Serializable, Callable<TemporaryResult> 
{
	private Closure<V> closure;
	private int slotIndex;
	private Result result;
	
	@Override
	abstract public TemporaryResult call() throws Exception;
	
	abstract public Task<V> generateSubTask();
	abstract public Closure<V> generateSuccessor();
}
