package api;

import java.util.ArrayList;
import java.util.List;

public class Closure <T> {
	private List<T> argumentList;
	private int missingArgCount;
	private Task task;
	public Closure(int argCount, Task task) {
		this.missingArgCount = argCount;
		this.argumentList = new ArrayList<T>(argCount);
		this.task = task;
	}
	public void insertArg(T arg, int index) {
		this.argumentList.set(index, arg);
		this.missingArgCount --;
	}
	public int getMissingArgCount() {
		return this.missingArgCount;
	}
}