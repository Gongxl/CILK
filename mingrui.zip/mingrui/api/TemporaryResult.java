package api;

import java.io.Serializable;


public class TemporaryResult  implements Serializable{
    private final Type type;
    public enum Type {SUCCESSOR, VALUE}
    public Type getType() {
    	return this.type;
    }
}
