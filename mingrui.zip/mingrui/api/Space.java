package api;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import system.Computer;

/**
 *
 * @author Mingrui Lyu
 */
public interface Space extends Remote 
{
    public static int PORT = 8001;
    public static String SERVICE_NAME = "Space";    
    
    <T> void putAll (List<Task<T>> taskList) throws RemoteException;    
    
    <T> Result<T> take() throws RemoteException;

    void exit() throws RemoteException;
    
    void register(Computer computer) throws RemoteException;
    
    <T> void issueNewTask(Task<T> newTask);
    
    <T> void generateSuccessor(Closure<T> successor);
    
    <T> Task<T> fetchTask();
    
    <T> void restoreTask(Task<T> task);
}